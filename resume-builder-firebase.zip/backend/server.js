const express = require('express');
const { OpenAI } = require('openai');
const cors = require('cors');
const admin = require('firebase-admin');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

// --- Firebase Admin Initialization ---
// Expect the following env vars:
// FIREBASE_PROJECT_ID, FIREBASE_CLIENT_EMAIL, FIREBASE_PRIVATE_KEY
// Note: for FIREBASE_PRIVATE_KEY, paste with \n for newlines, we'll replace them here.
const projectId = process.env.FIREBASE_PROJECT_ID;
const clientEmail = process.env.FIREBASE_CLIENT_EMAIL;
const privateKey = process.env.FIREBASE_PRIVATE_KEY && process.env.FIREBASE_PRIVATE_KEY.replace(/\\n/g, '\n');

if (!projectId || !clientEmail || !privateKey) {
  console.warn('⚠️ Missing Firebase env vars. Set FIREBASE_PROJECT_ID, FIREBASE_CLIENT_EMAIL, FIREBASE_PRIVATE_KEY');
}

admin.initializeApp({
  credential: admin.credential.cert({
    projectId,
    clientEmail,
    privateKey,
  }),
});

const db = admin.firestore();
const resumesCol = db.collection('resumes');

// --- OpenAI ---
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// Save resume data (stores under document id 'default' to match existing frontend)
app.post('/api/resume/save', async (req, res) => {
  const { data } = req.body;
  try {
    await resumesCol.doc('default').set({ data }, { merge: true });
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

// Get resume data
app.get('/api/resume/get', async (req, res) => {
  try {
    const snap = await resumesCol.doc('default').get();
    if (!snap.exists) return res.json({});
    const docData = snap.data();
    res.json(docData && docData.data ? docData.data : {});
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

// AI suggestions
app.post('/api/suggest', async (req, res) => {
  const { section, content } = req.body;
  const prompt = `Suggest improvements for this resume ${section}. Focus on clarity, impact, and keywords. Original content: ${content}`;
  try {
    const response = await openai.chat.completions.create({
      model: 'gpt-3.5-turbo',
      messages: [{ role: 'user', content: prompt }],
      max_tokens: 200,
      temperature: 0.7,
    });
    res.json({ suggestions: response.choices[0].message.content });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
