# Switched from MongoDB/Mongoose to Firebase Firestore

## What changed
- Removed `mongoose` and connection code.
- Added `firebase-admin` and Firestore initialization via service account.
- Kept the same REST endpoints so the React frontend does not change:
  - `POST /api/resume/save` — saves `{ data }` into Firestore at `resumes/default`.
  - `GET /api/resume/get` — fetches the saved data from `resumes/default`.
  - `POST /api/suggest` — unchanged; still uses OpenAI.

## Setup steps
1. In the Firebase console, create a project (if you don't have one).
2. Go to **Project Settings → Service Accounts → Generate new private key**.
3. Copy the credentials into `backend/.env`:
   - `FIREBASE_PROJECT_ID`
   - `FIREBASE_CLIENT_EMAIL`
   - `FIREBASE_PRIVATE_KEY` (replace real newlines with `\n`).
4. Install deps in `backend/`:
   ```bash
   npm install
   ```
5. Run the server:
   ```bash
   npm start
   ```

## Data model
- Collection: `resumes`
- Document id: `default` (to match existing frontend usage)
- Document shape:
  ```json
  {
    "data": { /* the resumeData object from the frontend */ }
  }
  ```

## Notes
- If you want per-user storage, change the document id from `'default'` to a user id (e.g., Firebase Auth uid) on both save/get routes.
- For local `.env` files, remember to escape newlines in `FIREBASE_PRIVATE_KEY` as `\n`.
