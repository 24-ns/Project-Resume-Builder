import { useState, useEffect } from 'react';
import axios from 'axios';
import ResumeForm from './components/ResumeForm';
import ResumePreview from './components/ResumePreview';
import { SunIcon, MoonIcon } from '@heroicons/react/24/solid';

function App() {
  const [resumeData, setResumeData] = useState({
    personal: { name: '', email: '', phone: '', location: '' },
    summary: '',
    experience: [],
    education: [],
    skills: [],
  });
  const [suggestions, setSuggestions] = useState({});
  const [theme, setTheme] = useState('light');

  useEffect(() => {
    axios.get('http://localhost:5000/api/resume/get')
      .then(res => setResumeData(res.data))
      .catch(err => console.error(err));
  }, []);

  const updateData = (section, value) => {
    setResumeData(prev => ({ ...prev, [section]: value }));
  };

  const saveResume = () => {
    axios.post('http://localhost:5000/api/resume/save', { data: resumeData })
      .then(() => alert('Resume saved!'))
      .catch(err => console.error(err));
  };

  const getSuggestions = (section, content) => {
    axios.post('http://localhost:5000/api/suggest', { section, content })
      .then(res => {
        setSuggestions(prev => ({ ...prev, [section]: res.data.suggestions }));
      })
      .catch(err => console.error(err));
  };

  const exportPDF = () => {
    window.print();
  };

  const toggleTheme = () => {
    setTheme(theme === 'light' ? 'dark' : 'light');
  };

  return (
    <div className={`min-h-screen ${theme === 'light' ? 'light-theme' : 'dark-theme'} transition-all duration-300`}>
      <div className="flex flex-col md:flex-row">
        <div className="w-full md:w-1/2 p-4 no-print">
          <ResumeForm
            data={resumeData}
            updateData={updateData}
            getSuggestions={getSuggestions}
            suggestions={suggestions}
            saveResume={saveResume}
          />
          <button
            onClick={exportPDF}
            className="mt-4 bg-blue-500 text-white px-4 py-2 rounded w-full md:w-auto"
          >
            Export to PDF (Print)
          </button>
        </div>
        <div className="w-full md:w-1/2 p-4 preview">
          <ResumePreview data={resumeData} />
        </div>
      </div>
      <button
        onClick={toggleTheme}
        className="theme-switch"
        aria-label="Toggle theme"
      >
        {theme === 'light' ? (
          <MoonIcon className="w-6 h-6" />
        ) : (
          <SunIcon className="w-6 h-6" />
        )}
      </button>
    </div>
  );
}

export default App;