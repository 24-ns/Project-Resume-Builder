import { useState } from 'react';

const ResumeForm = ({ data, updateData, getSuggestions, suggestions, saveResume }) => {
  const [newExp, setNewExp] = useState({ title: '', company: '', dates: '', description: '' });
  const [newEdu, setNewEdu] = useState({ degree: '', school: '', dates: '' });
  const [newSkill, setNewSkill] = useState('');

  const addExperience = () => {
    updateData('experience', [...data.experience, newExp]);
    setNewExp({ title: '', company: '', dates: '', description: '' });
  };

  const addEducation = () => {
    updateData('education', [...data.education, newEdu]);
    setNewEdu({ degree: '', school: '', dates: '' });
  };

  const addSkill = () => {
    updateData('skills', [...data.skills, newSkill]);
    setNewSkill('');
  };

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold">Personal Info</h2>
      <input
        className="border p-2 w-full rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
        placeholder="Name"
        value={data.personal.name}
        onChange={e => updateData('personal', { ...data.personal, name: e.target.value })}
      />
      <input
        className="border p-2 w-full rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
        placeholder="Email"
        value={data.personal.email}
        onChange={e => updateData('personal', { ...data.personal, email: e.target.value })}
      />
      <input
        className="border p-2 w-full rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
        placeholder="Phone"
        value={data.personal.phone}
        onChange={e => updateData('personal', { ...data.personal, phone: e.target.value })}
      />
      <input
        className="border p-2 w-full rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
        placeholder="Location"
        value={data.personal.location}
        onChange={e => updateData('personal', { ...data.personal, location: e.target.value })}
      />

      <h2 className="text-xl font-bold">Summary</h2>
      <textarea
        className="border p-2 w-full rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
        placeholder="Professional Summary"
        value={data.summary}
        onChange={e => updateData('summary', e.target.value)}
      />
      <button
        className="bg-green-500 text-white px-2 py-1 rounded hover:bg-green-600"
        onClick={() => getSuggestions('summary', data.summary)}
      >
        Get AI Suggestions
      </button>
      {suggestions.summary && <p className="mt-2 text-sm">{suggestions.summary}</p>}

      <h2 className="text-xl font-bold">Experience</h2>
      {data.experience.map((exp, i) => (
        <div key={i} className="border p-2 mb-2 rounded">
          <p>{exp.title} at {exp.company} ({exp.dates})</p>
          <p>{exp.description}</p>
          <button
            className="bg-green-500 text-white px-2 py-1 text-xs rounded hover:bg-green-600"
            onClick={() => getSuggestions(`experience-${i}`, exp.description)}
          >
            Suggest for this
          </button>
          {suggestions[`experience-${i}`] && (
            <p className="mt-1 text-sm">{suggestions[`experience-${i}`]}</p>
          )}
        </div>
      ))}
      <input
        className="border p-2 w-full rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
        placeholder="Title"
        value={newExp.title}
        onChange={e => setNewExp({ ...newExp, title: e.target.value })}
      />
      <input
        className="border p-2 w-full rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
        placeholder="Company"
        value={newExp.company}
        onChange={e => setNewExp({ ...newExp, company: e.target.value })}
      />
      <input
        className="border p-2 w-full rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
        placeholder="Dates"
        value={newExp.dates}
        onChange={e => setNewExp({ ...newExp, dates: e.target.value })}
      />
      <textarea
        className="border p-2 w-full rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
        placeholder="Description"
        value={newExp.description}
        onChange={e => setNewExp({ ...newExp, description: e.target.value })}
      />
      <button
        className="bg-blue-500 text-white px-2 py-1 rounded hover:bg-blue-600"
        onClick={addExperience}
      >
        Add Experience
      </button>

      <h2 className="text-xl font-bold">Education</h2>
      {data.education.map((edu, i) => (
        <div key={i} className="border p-2 mb-2 rounded">
          <p>{edu.degree} from {edu.school} ({edu.dates})</p>
        </div>
      ))}
      <input
        className="border p-2 w-full rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
        placeholder="Degree"
        value={newEdu.degree}
        onChange={e => setNewEdu({ ...newEdu, degree: e.target.value })}
      />
      <input
        className="border p-2 w-full rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
        placeholder="School"
        value={newEdu.school}
        onChange={e => setNewEdu({ ...newEdu, school: e.target.value })}
      />
      <input
        className="border p-2 w-full rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
        placeholder="Dates"
        value={newEdu.dates}
        onChange={e => setNewEdu({ ...newEdu, dates: e.target.value })}
      />
      <button
        className="bg-blue-500 text-white px-2 py-1 rounded hover:bg-blue-600"
        onClick={addEducation}
      >
        Add Education
      </button>

      <h2 className="text-xl font-bold">Skills</h2>
      <ul className="list-disc pl-5">
        {data.skills.map((skill, i) => (
          <li key={i}>{skill}</li>
        ))}
      </ul>
      <input
        className="border p-2 w-full rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
        placeholder="New Skill"
        value={newSkill}
        onChange={e => setNewSkill(e.target.value)}
      />
      <button
        className="bg-blue-500 text-white px-2 py-1 rounded hover:bg-blue-600"
        onClick={addSkill}
      >
        Add Skill
      </button>
      <button
        className="bg-green-500 text-white px-2 py-1 rounded hover:bg-green-600"
        onClick={() => getSuggestions('skills', data.skills.join(', '))}
      >
        Get AI Suggestions
      </button>
      {suggestions.skills && <p className="mt-2 text-sm">{suggestions.skills}</p>}

      <button
        className="mt-4 bg-purple-500 text-white px-4 py-2 rounded hover:bg-purple-600 w-full md:w-auto"
        onClick={saveResume}
      >
        Save Resume
      </button>
    </div>
  );
};

export default ResumeForm;