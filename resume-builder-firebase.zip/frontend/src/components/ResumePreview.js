const ResumePreview = ({ data }) => {
  return (
    <div className="p-8 bg-white shadow-md text-gray-900">
      <h1 className="text-3xl font-bold text-center">{data.personal.name}</h1>
      <p className="text-center text-gray-600">
        {data.personal.email} | {data.personal.phone} | {data.personal.location}
      </p>
      <hr className="my-4" />

      <h2 className="text-xl font-semibold">Professional Summary</h2>
      <p className="mt-2">{data.summary}</p>

      <h2 className="text-xl font-semibold mt-6">Experience</h2>
      {data.experience.map((exp, i) => (
        <div key={i} className="mt-2">
          <h3 className="font-bold">{exp.title} - {exp.company}</h3>
          <p className="text-gray-600">{exp.dates}</p>
          <p>{exp.description}</p>
        </div>
      ))}

      <h2 className="text-xl font-semibold mt-6">Education</h2>
      {data.education.map((edu, i) => (
        <div key={i} className="mt-2">
          <h3 className="font-bold">{edu.degree} - {edu.school}</h3>
          <p className="text-gray-600">{edu.dates}</p>
        </div>
      ))}

      <h2 className="text-xl font-semibold mt-6">Skills</h2>
      <ul className="list-disc pl-5 mt-2">
        {data.skills.map((skill, i) => (
          <li key={i}>{skill}</li>
        ))}
      </ul>
    </div>
  );
};

export default ResumePreview;