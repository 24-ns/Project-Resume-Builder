# Smart Resume Builder

A web-based resume builder with AI-powered suggestions, PDF export, and theme switching (light: white-gray gradient, dark: gray-black gradient).

## Prerequisites
- Node.js (v18+)
- MongoDB Atlas account
- OpenAI API key (sign up at platform.openai.com)

## Setup

### Backend
1. Navigate to `backend/`.
2. Copy `.env.example` to `.env` and fill in `MONGO_URI` and `OPENAI_API_KEY`.
3. Install dependencies: npm install
4. Run the server: npm start 
### Frontend
1. Navigate to `frontend/`.
2. Install dependencies: npm install
3. Run the app: npm start 

## Usage
- Fill in resume details in the form.
- Click "Get AI Suggestions" for improvements.
- Save resume to MongoDB with "Save Resume".
- Export to PDF using "Export to PDF" (browser print).
- Toggle themes (light/dark) with the button at bottom-right.

## Features
- Interactive form with real-time preview.
- AI suggestions via OpenAI GPT-3.5-turbo.
- MongoDB storage.
- Responsive design (mobile/desktop).
- Theme switch: white-gray gradient (light), gray-black gradient (dark).
- Clean PDF export with print styles.